# Setup and Deployment Guide

Local Development Setup

Prerequisites:
- Node.js (version 18 or 20)
- npm package manager

Steps to Run Locally:

1. Clone the repository:
   git clone https://github.com/Priyangshu0011/ERP-CRM-Operations-Portal.git
   cd ERP-CRM-Operations-Portal

2. Setup and start the backend:
   cd backend
   npm install
   npx prisma db push
   npm run prisma:seed
   npm run dev

3. Setup and start the frontend in a separate terminal:
   cd frontend
   npm install
   npm run dev

4. Open http://localhost:3000 in your browser. Log in using any of the pre-seeded accounts with password: password123

---

Cloud Deployment Guide

Backend Deployment on Render:
1. Create a Web Service on Render connected to the repository.
2. Set Root Directory to backend.
3. Set Build Command to: npm install && npx prisma generate && npm run build
4. Set Start Command to: npx prisma db push && npm run prisma:seed && npm start
5. Add environment variables: NODE_ENV=production, JWT_SECRET=supersecret_jwt_key_erp_crm_2026 and DATABASE_URL=file:./dev.db.

Frontend Deployment on Vercel:
1. Import the repository on Vercel.
2. Set Root Directory to frontend.
3. Select Framework Preset as Vite.
4. Set Build Command to: npm run build
5. Add environment variable: VITE_API_URL=https://mini-erp-backend-sb2u.onrender.com/api.
