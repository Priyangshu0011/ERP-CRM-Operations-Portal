# System Architecture

Architecture Overview

The application follows a decoupled client-server architecture.

The frontend is a single-page application built using React, Vite and TypeScript. Styling is built using Tailwind CSS. Navigation tabs and action buttons dynamically render based on the logged-in user role.

The backend REST API is constructed using Express and TypeScript. API controllers handle data operations through Prisma ORM.

Key Engineering Features:

1. Role-Based Access Control:
   Backend endpoints enforce role rules via requireRole middleware. The frontend conditionally hides mutation buttons for roles without write access.

2. Atomic Inventory Transactions:
   Stock deductions upon order confirmation run within a database transaction (prisma.$transaction). Stock availability is checked prior to deduction to prevent negative stock values.

3. Historical Item Snapshots:
   Line items in sales challans store immutable snapshots of product names, SKUs and unit prices. Modifications or deletions in the product catalog do not affect past invoices or revenue records.
