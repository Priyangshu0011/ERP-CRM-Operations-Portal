# API Documentation

Base URLs:
- Local: http://localhost:5000/api
- Production: https://mini-erp-backend-sb2u.onrender.com/api

Endpoints Overview:

1. Authentication:
   - POST /auth/login: Authenticate email and password, returning a JWT token.
   - GET /auth/me: Retrieve profile details for the authenticated user.

2. Customer CRM:
   - GET /customers: List customer accounts with search and status filtering.
   - POST /customers: Create a new customer profile (Admin and Sales roles).
   - POST /customers/:id/notes: Add follow-up notes and update pipeline status (Admin and Sales roles).

3. Product and Inventory:
   - GET /products: Retrieve product catalog with low stock filter.
   - POST /products: Add a new product (Admin and Warehouse roles).
   - POST /products/:id/adjust-stock: Record manual stock IN or OUT adjustments with reason logging (Admin and Warehouse roles).
   - GET /products/stock-logs: Retrieve historical inventory movement audit logs.

4. Sales Challans:
   - GET /challans: List sales orders and invoices.
   - POST /challans: Create draft or confirmed sales orders (Admin and Sales roles).
   - PATCH /challans/:id/status: Update sales order status to Confirmed or Cancelled (Admin and Sales roles).
