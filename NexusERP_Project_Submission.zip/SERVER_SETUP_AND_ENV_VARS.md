# Server Setup and Environment Variables Management

Server Setup Overview

The backend server is built using Node.js, Express and TypeScript.

The main entry point is initialized in backend/src/index.ts, configuring CORS headers and body parsing at startup. Authentication is managed using JSON Web Tokens (JWT) and passwords are encrypted using bcrypt hashing.

API routing is divided into modular controllers:
- authRoutes: Authentication and profile endpoints.
- customerRoutes: Customer account management and follow-up logging endpoints.
- productRoutes: Product catalog, stock adjustment and inventory log endpoints.
- challanRoutes: Sales challan creation, status updates and tax invoice endpoints.

Route authorization is controlled through custom Express middleware:
- authenticateJWT verifies Bearer tokens and attaches the authenticated user profile to the request object.
- requireRole enforces role permissions and returns a 403 status code for unauthorized role attempts.

Database operations are handled using Prisma ORM with SQLite (backend/prisma/schema.prisma). The database schema defines models for User, Customer, CustomerNote, Product, StockLog, SalesChallan and ChallanItem.

An automated seeding script (backend/prisma/seed.ts) seeds the database with initial user accounts for all four roles, sample customer accounts, product stock items and sales orders.

---

Environment Variables Management

Environment configuration is isolated between backend and frontend environments.

Backend Environment Variables (backend/.env):
- PORT: Server port number (default 5000).
- NODE_ENV: Environment setting (development or production).
- JWT_SECRET: Secret key used for signing and verifying tokens.
- DATABASE_URL: Prisma database connection string (file:./dev.db).

Frontend Environment Variables (frontend/.env):
- VITE_API_URL: Base URL for backend API requests (http://localhost:5000/api in development and https://mini-erp-backend-sb2u.onrender.com/api in production).

Automated Pipeline and Host Configuration:
In GitHub Actions (.github/workflows/ci.yml), environment variables (DATABASE_URL and JWT_SECRET) are passed during automated testing. On Render and Vercel hosting services, environment variables are configured directly in their respective dashboard settings.
