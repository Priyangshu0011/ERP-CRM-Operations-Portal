# Project Links and Test Credentials

Project Repositories and Live Deployments

- GitHub Repository: https://github.com/Priyangshu0011/ERP-CRM-Operations-Portal
- Live Frontend Portal: https://erp-crm-operations-portal-pi.vercel.app
- Live Backend REST API: https://mini-erp-backend-sb2u.onrender.com

---

Test Login Credentials

All test accounts share the same password: password123

1. Admin Role
   Email: admin@erp.com
   Scope: Full system access across CRM, inventory, sales orders and financial auditing.

2. Sales Role
   Email: sales@erp.com
   Scope: Customer management, CRM follow-up logging and sales order creation.

3. Warehouse Role
   Email: warehouse@erp.com
   Scope: Product catalog management, manual stock IN/OUT adjustments and inventory movement logs.

4. Accounts Role
   Email: accounts@erp.com
   Scope: Financial auditing for sales orders, customer billing data and tax invoice generation.
