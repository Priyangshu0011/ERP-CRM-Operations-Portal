# Assumptions Made and Known Limitations

Assumptions Made:

1. SQLite Database Choice: SQLite is used as the default database engine to allow immediate local execution without local database installation.
2. Pre-seeded Role Accounts: Accounts for all four roles are pre-seeded with password password123 to enable instant evaluation.
3. Currency Unit: All financial values are assumed to be in Indian Rupees (INR).
4. Stock Deduction Trigger: Stock is deducted when a sales order is set to Confirmed status. Draft orders do not deduct inventory.
5. Image Reference Format: Product images use direct HTTPS web links rather than file upload buckets.

---

Known Limitations:

1. Free Hosting Server Warmup: The backend is hosted on a free Render service that goes idle after inactivity. Initial requests may take roughly 30 seconds to wake up the server.
2. Invoice Generation: Invoices currently generate through browser native print rendering styled with media print CSS.
